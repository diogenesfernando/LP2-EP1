/// Linguagem de programa��o 2 - Primeiro Roteiro - Multiplica��o de matrizes com threads /// #############
/// Alunos : Sabrina Silva  2016022764, Diogenes Chavier 2016016847, St�nio Ellison  2016068763           #
/// Engenharia da computa��o, UFPB , Mar�o 2018 ///                                                       #
///########################################################################################################

#include<iostream>
#include<string>
#include<thread>
#include<random>
#include<chrono>
#include <cstdlib>



using namespace std::chrono;
using namespace std;


///ALTERE AQUI O TAMANHO DA MATRIZ E O NUMERO DE THREADS ANTES DE EXECUTAR O CODIGO///

#define ORDEM 20        //definir aqui a ordem das matrizes quadradas ORDEM x ORDEM (TAMANHO)
#define NUMTHREADS 20      //definir aqui a quantidade de threads utilizadas para multiplicacao (quando for o caso)


/// Variaveis globais///

int matrizA[ORDEM][ORDEM];
int matrizB[ORDEM][ORDEM];
int matrizResultado[ORDEM][ORDEM];
int aux_i = 0;
int opcaoMenu;

/// Assinatura das funcoes utilizadas ///

void* MultiplicaMatrizesComNthreads(void* argumento);
void GeraMatrizRandom();
void ImprimeMatriz (std::string descricao,int matriz[ORDEM][ORDEM]);
void ChamaThreads();
void MultiplicaMatrizesSequencial();

///_________________________________///
///    Inicializacao do programa   ///

int main()
{

     ///Menu do programa_________________________________________________________________________________________________________

    cout<< "\nEste programa calcula o produto entre duas matrizes, A e B,"<<"\n"<<" geradas automaticamente e  com numeros preenchidos aleatoriamente" <<endl;
    cout<< "\n(Para mudar o tamanho(ORDEM) das matrizes e o numero de threads(NUNUMTHREADSM)" <<"\n"<<"altere os valores das variaveis no cabecalho do codigo)"<<endl;
    cout<< "\n\n Escolha uma opcao para calcular o produtos das funcoes"<<endl;
    cout <<"\n1- Calcular usando metodo sequencial " << "\n" << "2- Calcular usando um numero especifico de threads" <<"\n"<< "0- SAIR do programa"<<endl;
    cin>> opcaoMenu;

   ///___________________________________________________________________________________________________________________________

   /// Execu��o de opera��es ///_________________________________________________________________________________________________

    if (opcaoMenu == 0 ){ exit(0); }
        else if (opcaoMenu == 1 ){

                GeraMatrizRandom();                                                 //gera UM PAR  de matrizes quadradas de valores aleatorios com dimensao definida na variavel ORDEM
                ImprimeMatriz("## MATRIZ A ##",matrizA);                           //imprime a primeira matriz criada
                ImprimeMatriz("## MATRIZ B ##",matrizB);                          //imprime a segunda matriz criada
                MultiplicaMatrizesSequencial();                                  //faz a multiplicacao das matrizes a e b de forma sequencial
                ImprimeMatriz("## MATRIZ RESULTADO ##",matrizResultado);        //imprime a matriz resultante da multiplicacao

}
             else if (opcaoMenu == 2){

                GeraMatrizRandom();                                                //gera UM PAR  de matrizes quadradas de valores aleatorios com dimensao definida na variavel ORDEM
                ImprimeMatriz("## MATRIZ A ##",matrizA);                          //imprime a primeira matriz criada
                ImprimeMatriz("## MATRIZ B ##",matrizB);                         // imprime a segunda matriz criada

  auto begin = std::chrono::high_resolution_clock::now();


                ChamaThreads();                                               //cria e execulta multiplicacao das matrizes atravez do numero de threads especificados em NUMTHREADS, recursivamente chama a funcao MultiplicaMatrizesComNthreads
 auto end = std::chrono::high_resolution_clock::now();
 std::cout << "\n\n Tempo para realizar a multiplicacao com threads : "<< std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count() << " nanosegundos \n" << std::endl;


              ImprimeMatriz("##  MATRIZ RESULTADO ##",matrizResultado);    //imprime a matriz resultante da multiplicacao


    }     else { cout<< "####  opcao invalida, vamos tentar novamente ####"<<endl;    //tratamento de erro, retorna a execucao do programa do inicio
                        return main();
        }



    system("PAUSE");
}



///_____________________________________________________Declara��o de Fun��es____________________________________________________________________________///


void ChamaThreads(){                                                                             //funcao que cria, execulta e junta as threads, trabalha recursivamente com a funcao MultiplicaMatrizesComNthreads

    pthread_t threads[NUMTHREADS+1];                                                           //criando arrray de N threads

        for (int i = 0; i < NUMTHREADS; i++) {                                               //iniciando N threads  e chamando funcao de multiplicacao MultiplicaMatrizesComNthreads
        int* ponteiro;
        pthread_create(&threads[i], NULL, MultiplicaMatrizesComNthreads,(( void * )i));
        cout<<"\n"<<"tread criada e iniciada -> indice: "<<i<<endl;                       //linha de texto para acompanhar execu��o
    }

    // join
    for (int i = 0; i < NUMTHREADS; i++){                                              //juntando todas as threads e esperando a finaliza��o do processo
        pthread_join(threads[i], NULL);
        cout<<"\n"<<"tread "<<i<<" join"<<endl;                                      //linha de texto para verificar a sequencia do join
    }
}

void ImprimeMatriz (string descricao, int matriz[ORDEM][ORDEM]){                //funcao que imprime matizes

   cout<< "\n"<< descricao << endl;                                           //linha de titulo da matriz
    for (int i = 0; i < ORDEM; i++) {
        for (int j = 0; j < ORDEM; j++)
            cout << matriz[i][j] << " ";                                    //imorime matriz passada como parametro
        cout << endl;
    }
}

void GeraMatrizRandom(){                                                //cria um par de matrizes de dimensao ORDEM x ORDEM e as preenche com numeros aleatorios

    for (int i = 0; i < ORDEM; i++) {
        for (int j = 0; j < ORDEM; j++) {
            matrizA[i][j] = rand() % 10;                              //funcao rand: gera numeros aleatorios para os indices i e j da matriz
            matrizB[i][j] = rand() % 10;
        }
    }


}

void * MultiplicaMatrizesComNthreads(void* argumento){            //calcula a multiplicacao com threads


   int threadId = ( int)argumento;
   int i,j,k;
   for (i= ( threadId*(ORDEM/NUMTHREADS)); i<((threadId+1)*(ORDEM/NUMTHREADS) );i++){
            for (j=0;j<ORDEM;j++){
                matrizResultado [i][j]=0;
                  for (k=0;k<ORDEM;k++){
                      matrizResultado[i][j]+= matrizA[i][k]*matrizB[k][j] ;
        }
            }
               }
       pthread_exit(NULL) ;

}

void MultiplicaMatrizesSequencial(){                                 //funcao que multiplica as matrizes de forma sequencial

  auto begin = std::chrono::high_resolution_clock::now();          //salva tempo incial da execucao da funcao


       for (int i = 0; i < ORDEM; i++){
            cout<<"\n"<<"chamando funcao calcular sequencial"<<endl;
                for (int j = 0; j < ORDEM; j++)
                    for (int k = 0; k < ORDEM; k++)
                        matrizResultado[i][j] += matrizA[i][k] * matrizB[k][j];
            }
            cout<<"\n\n ##fim da multiplicacao sequencial##"<<endl;

  auto end = std::chrono::high_resolution_clock::now();
  std::cout << "\n\n Tempo para realizar a multiplicacao Sequencial : "<< std::chrono::duration_cast<std::chrono::nanoseconds>(end-begin).count() << " nanosegundos \n" << std::endl;

}
